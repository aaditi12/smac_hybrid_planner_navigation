#!/bin/bash
# ============================================================
# Diffbot Navigation - tmux launch script
# Constrained Indoor Navigation with AMCL + Smac Planner
# ============================================================
set -e

SESSION="diffbot_nav"
WS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SETUP="${WS_DIR}/install/setup.bash"

# Software rendering for VirtualBox / VM
export LIBGL_ALWAYS_SOFTWARE=1
export GAZEBO_MODEL_PATH="${WS_DIR}/install/diffbot_sim/share/diffbot_sim/models"

if [ ! -f "${SETUP}" ]; then
    echo "❌ ERROR: Workspace not built. Run ./build.sh first."
    exit 1
fi

# Kill existing session
tmux kill-session -t "$SESSION" 2>/dev/null || true
sleep 0.5

# Create tmux session with 5 panes
tmux new-session  -d -s "$SESSION" -x 260 -y 50

# Pane 0 – Gazebo
tmux send-keys -t "$SESSION:0" \
    "source '${SETUP}' && export LIBGL_ALWAYS_SOFTWARE=1 && \
     ros2 launch diffbot_sim gazebo.launch.py; exec bash" Enter

tmux split-window -h -t "$SESSION:0"

# Pane 1 – Nav2 (wait 8s for Gazebo + robot to settle)
tmux send-keys -t "$SESSION:0.1" \
    "source '${SETUP}' && sleep 8 && \
     ros2 launch diffbot_navigation navigation.launch.py \
       use_rviz:=true; exec bash" Enter

tmux split-window -v -t "$SESSION:0.0"

# Pane 2 – AMCL Monitor
tmux send-keys -t "$SESSION:0.2" \
    "source '${SETUP}' && sleep 12 && \
     ros2 run diffbot_bringup amcl_monitor.py; exec bash" Enter

tmux split-window -v -t "$SESSION:0.1"

# Pane 3 – Optional: Teleop or Mission
tmux send-keys -t "$SESSION:0.3" \
    "source '${SETUP}' && sleep 15 && echo '' && \
     echo '=============================================' && \
     echo '  Diffbot Navigation Ready!' && \
     echo '  Option A: Teleoperate' && \
     echo '    ros2 run teleop_twist_keyboard teleop_twist_keyboard' && \
     echo '  Option B: Run autonomous waypoint mission' && \
     echo '    ros2 run diffbot_bringup waypoint_mission.py' && \
     echo '  Option C: Save current SLAM map' && \
     echo '    ros2 run diffbot_bringup map_saver.py' && \
     echo '=============================================' && \
     exec bash" Enter

# Layout: left half = Gazebo, right half split top/bottom
tmux select-layout -t "$SESSION" tiled
tmux select-pane -t "$SESSION:0.0"

echo ""
echo "================================================"
echo "  Diffbot Navigation started in tmux session: $SESSION"
echo "================================================"
echo ""
echo "  Attach:    tmux attach -t $SESSION"
echo "  Kill:      tmux kill-session -t $SESSION"
echo ""
echo "  Pane 0 → Gazebo"
echo "  Pane 1 → Nav2 (AMCL + Smac Planner + RViz)"
echo "  Pane 2 → AMCL Monitor"
echo "  Pane 3 → Mission launch / manual commands"
echo ""
echo "  💡 Workflow:"
echo "    PHASE 1 - SLAM Mapping:"
echo "      tmux new-window + ros2 launch diffbot_navigation slam.launch.py"
echo "      Drive manually, then: ros2 run diffbot_bringup map_saver.py"
echo ""
echo "    PHASE 2 - AMCL Navigation:"
echo "      Already launched above with pre-built map."
echo "      Set 2D Pose Estimate in RViz, then:"
echo "        ros2 run diffbot_bringup waypoint_mission.py"
echo ""
tmux attach -t "$SESSION"
