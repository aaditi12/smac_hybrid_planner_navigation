# Diffbot Navigation in Constrained Indoor Environments
## AMCL Localization + Smac Hybrid-A* Planner on ROS 2 Humble

---

## 🏗️ Project Overview

This project simulates a **differential drive cardboard robot** navigating through a **constrained indoor environment** featuring:

- **1.2m-wide main corridor** (tight for a 0.34m-wide robot)
- **0.7m doorways** into side rooms with furniture obstacles
- **Pillar zone** creating ~0.6m passages per side
- **Dynamic obstacle** (movable box) in corridor
- Room A, B, C with tables, chairs, and shelves

### Stack
| Layer | Technology | Purpose |
|---|---|---|
| **Simulation** | Gazebo Classic | Physics, sensors, actuation |
| **URDF** | Xacro | Diff-drive robot (cardbot) with 2D LiDAR + IMU |
| **Mapping** | SLAM Toolbox | Online async SLAM for map generation |
| **Localization** | **Nav2 AMCL** | Monte Carlo particle filter localization |
| **Global Planner** | **Smac Hybrid-A*** | Kinematically-feasible path planning |
| **Local Planner** | Regulated Pure Pursuit | Smooth, constraint-aware tracking |
| **Costmaps** | Nav2 (0.03m res) | Fine-grained for narrow passages |
| **Mission** | Python Action Client | 14-waypoint autonomous circuit |

---

## 🤖 Robot Specification

```
┌─────────────────────────────────┐
│  Base: 0.28m × 0.20m × 0.08m   │
│  Wheel separation: 0.215m       │
│  Wheel radius: 0.033m           │
│  Robot footprint radius: 0.17m  │
│  Min turning radius: 0.30m      │
│  Max velocity: 0.18 m/s (nav)   │
│  Sensors: 360° LiDAR, IMU       │
└─────────────────────────────────┘
```

---

## 📂 Workspace Structure

```
diffbot_nav_ws/
├── build.sh                         ← Install deps + build
├── run.sh                           ← Launch everything in tmux
└── src/
    ├── diffbot_description/         ← URDF/Xacro robot model
    │   └── urdf/diffbot.urdf.xacro  (diff-drive + lidar + IMU + plugins)
    │
    ├── diffbot_sim/                 ← Gazebo simulation
    │   └── worlds/
    │       └── constrained_indoor.world  (corridors, rooms, pillars)
    │
    ├── diffbot_navigation/          ← Nav2 configuration
    │   ├── config/
    │   │   ├── nav2_params.yaml     (AMCL + Smac + RPP tuned params)
    │   │   └── slam_toolbox_params.yaml
    │   ├── maps/
    │   │   ├── constrained_indoor.pgm   (pre-built map)
    │   │   └── constrained_indoor.yaml
    │   ├── rviz/navigation.rviz
    │   └── launch/
    │       ├── slam.launch.py       (mapping phase)
    │       ├── navigation.launch.py (AMCL + Nav2)
    │       └── bringup.launch.py    (Gazebo + Nav2 together)
    │
    └── diffbot_bringup/             ← Mission scripts
        └── scripts/
            ├── waypoint_mission.py  (14-waypoint autonomous mission)
            ├── amcl_monitor.py      (localization quality monitor)
            └── map_saver.py         (save SLAM map to disk)
```

---

## 🚀 Quick Start

### Step 1 — Build

```bash
cd diffbot_nav_ws
chmod +x build.sh run.sh
./build.sh
source install/setup.bash
```

### Step 2 — Option A: Use Pre-built Map (Jump to Navigation)

```bash
./run.sh
# This starts: Gazebo + Nav2 (AMCL + Smac) + RViz + AMCL monitor
```

Then in RViz:
1. Click **"2D Pose Estimate"** → click on map at `(-0.5, 0.0)` pointing right
2. Wait for AMCL particles to converge (~3 seconds of driving)
3. Click **"Nav2 Goal"** or run the mission script

### Step 2 — Option B: Build Your Own Map First

```bash
# Terminal 1 - Start SLAM + Gazebo
ros2 launch diffbot_navigation slam.launch.py

# Terminal 2 - Drive the robot around manually
ros2 run teleop_twist_keyboard teleop_twist_keyboard

# Terminal 3 - When done mapping, save the map
ros2 run diffbot_bringup map_saver.py --ros-args -p output_path:=src/diffbot_navigation/maps/constrained_indoor

# Then rebuild/reinstall:
colcon build --symlink-install
```

### Step 3 — Run Autonomous Mission

```bash
# After Nav2 is running and AMCL is localized:
ros2 run diffbot_bringup waypoint_mission.py

# Loop mode:
ros2 run diffbot_bringup waypoint_mission.py --ros-args -p loop:=true

# Monitor AMCL quality in parallel:
ros2 run diffbot_bringup amcl_monitor.py
```

---

## 🗺️ Environment Layout

```
N
^
|
┌──────────────────────────────────────────────┐
│  ┌───────────┐  ┌───────────┐               │
│  │  Room A   │  │  Room B   │               │
│  │  🪑🪑     │  │  📦📦📦  │    CORRIDOR   │
│  │   🗃️     │  │           │ ──→ ⬤ ⬤ ──→│
│  └──┤ ├──────┘  └──┤ ├─────┘               │
│    door            door    ────────────────  │
│  ════ MAIN CORRIDOR ═══════════════════════  │
│    door                                      │
│  ┌──┤ ├───────────┐                         │
│  │  Room C        │   (open corridor south)  │
│  │  📦            │                         │
│  └────────────────┘                         │
└──────────────────────────────────────────────┘
    ⬤ = pillars (tight zone, 0.6m effective gap)
```

---

## ⚙️ Key Parameter Decisions

### AMCL Tuning for Tight Corridors

| Parameter | Value | Reason |
|---|---|---|
| `update_min_d` | 0.05m | Update on very small motion |
| `update_min_a` | 0.1 rad | Catch small turns in corridors |
| `max_particles` | 3000 | Good coverage without overhead |
| `laser_model_type` | `likelihood_field` | Best for structured environments |
| `recovery_alpha_fast` | 0.001 | Slow recovery (stable map) |

### Smac Hybrid-A* for Diff-Drive

| Parameter | Value | Reason |
|---|---|---|
| `motion_model` | `REEDS_SHEPP` | Kinematically exact for diff-drive |
| `minimum_turning_radius` | 0.30m | Matches cardbot dynamics |
| `angle_quantization_bins` | 72 | 5° resolution, good narrow path detail |
| `reverse_penalty` | 2.0 | Allow reversing in extremis |
| `max_planning_time` | 5.0s | Allow complex path computation |

### Costmap Resolution for Narrow Passages

| Parameter | Value | Reason |
|---|---|---|
| `resolution` | 0.03m | 3cm cells: model 0.7m doorways with 23 cells |
| `robot_radius` | 0.17m | True footprint, not inflated |
| `inflation_radius` | 0.35m | Just fits through doorways with margin |
| `cost_scaling_factor` | 5.0 | Aggressive decay: safe center of passage |

---

## 🔍 Troubleshooting

### Robot not moving / Nav2 can't plan
- Ensure AMCL has converged: check `/particle_cloud` in RViz
- Re-publish initial pose: `ros2 topic pub /initialpose ...`
- Check costmap isn't fully inflated: reduce `inflation_radius`

### Robot gets stuck in doorways
- Verify `inflation_radius < 0.35` in both costmaps
- Check `robot_radius = 0.17` (not larger)
- Try `SmacHybrid` planner instead of `GridBased`

### AMCL diverging (particles spread out)
- Robot likely moved too fast through featureless corridor section
- Reduce max velocity: set `desired_linear_vel: 0.12` in RPP params
- Add more distinctive landmarks or improve LiDAR range/density

### Gazebo slow on VM
- Already set `LIBGL_ALWAYS_SOFTWARE=1` in launch files
- Reduce physics update rate in world: `<real_time_update_rate>500</real_time_update_rate>`
- Disable shadows in scene: `<shadows>false</shadows>` (already done)

### Smac planner timeout
- Increase `max_planning_time: 10.0`
- Reduce `max_iterations: 500000`
- If persistent, use `GridBased` as fallback for that waypoint

---

## 📡 Topics Reference

| Topic | Type | Description |
|---|---|---|
| `/scan` | `LaserScan` | 360° LiDAR @ 10Hz |
| `/odom` | `Odometry` | Wheel encoder odometry |
| `/imu` | `Imu` | IMU @ 200Hz |
| `/cmd_vel` | `Twist` | Velocity commands |
| `/map` | `OccupancyGrid` | Static map |
| `/amcl_pose` | `PoseWithCovariance` | AMCL localization output |
| `/particle_cloud` | `PoseArray` | AMCL particles |
| `/plan` | `Path` | Global plan (Smac) |
| `/local_plan` | `Path` | Local plan (RPP) |
| `/waypoint_markers` | `MarkerArray` | Mission waypoints in RViz |
| `/goal_pose` | `PoseStamped` | RViz 2D Goal input |

---

## 📄 License

Apache 2.0 — Krishna / Cardbot Project
