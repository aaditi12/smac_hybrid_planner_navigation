#!/bin/bash
# ============================================================
# Build script for Diffbot Navigation Workspace
# ============================================================
set -e

WS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$WS_DIR"

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║   Diffbot Navigation Workspace Builder               ║"
echo "║   AMCL + Smac Planner + Constrained Indoor Env      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check ROS 2 Humble
if [ -z "$ROS_DISTRO" ]; then
    if [ -f /opt/ros/humble/setup.bash ]; then
        source /opt/ros/humble/setup.bash
        echo "✅ Sourced ROS 2 Humble"
    else
        echo "❌ ROS 2 Humble not found. Install with:"
        echo "   sudo apt install ros-humble-desktop"
        exit 1
    fi
else
    echo "✅ ROS 2 ${ROS_DISTRO} detected"
fi

# Check required packages
echo ""
echo "Checking required packages..."
PKGS=(
    ros-humble-nav2-bringup
    ros-humble-nav2-smac-planner
    ros-humble-nav2-amcl
    ros-humble-nav2-map-server
    ros-humble-nav2-planner
    ros-humble-nav2-controller
    ros-humble-nav2-behaviors
    ros-humble-nav2-bt-navigator
    ros-humble-nav2-waypoint-follower
    ros-humble-nav2-lifecycle-manager
    ros-humble-nav2-regulated-pure-pursuit-controller
    ros-humble-slam-toolbox
    ros-humble-gazebo-ros-pkgs
    ros-humble-gazebo-ros2-control
    ros-humble-robot-state-publisher
    ros-humble-joint-state-publisher
    ros-humble-xacro
    ros-humble-teleop-twist-keyboard
    ros-humble-rviz2
    python3-colcon-common-extensions
)

MISSING=()
for pkg in "${PKGS[@]}"; do
    if ! dpkg -l "$pkg" &>/dev/null 2>&1; then
        MISSING+=("$pkg")
    fi
done

if [ ${#MISSING[@]} -gt 0 ]; then
    echo ""
    echo "⚠️  Missing packages detected. Installing..."
    sudo apt-get update -qq
    sudo apt-get install -y "${MISSING[@]}"
    echo "✅ Dependencies installed"
else
    echo "✅ All dependencies present"
fi

# Build
echo ""
echo "Building workspace..."
colcon build \
    --symlink-install \
    --cmake-args -DCMAKE_BUILD_TYPE=Release \
    --event-handlers console_direct+ \
    2>&1 | tee /tmp/diffbot_build.log

echo ""
echo "✅ Build complete!"
echo ""
echo "To use the workspace:"
echo "  source ${WS_DIR}/install/setup.bash"
echo ""
echo "Quick start:"
echo "  ./run.sh          — Launch everything in tmux"
echo ""
echo "Individual launches:"
echo "  # Phase 1: Build a map with SLAM"
echo "  ros2 launch diffbot_navigation slam.launch.py"
echo ""
echo "  # Phase 2: Navigate with AMCL + Smac Planner"
echo "  ros2 launch diffbot_navigation bringup.launch.py"
echo ""
echo "  # Run autonomous waypoint mission"
echo "  ros2 run diffbot_bringup waypoint_mission.py"
echo ""
echo "  # Monitor AMCL localization quality"
echo "  ros2 run diffbot_bringup amcl_monitor.py"
echo ""
