import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node, SetRemap


def generate_launch_description():
    pkg_nav    = get_package_share_directory('diffbot_navigation')
    pkg_nav2   = get_package_share_directory('nav2_bringup')

    use_sim_time  = LaunchConfiguration('use_sim_time',  default='true')
    map_yaml_file = LaunchConfiguration('map',           default=os.path.join(pkg_nav, 'maps', 'constrained_indoor.yaml'))
    params_file   = LaunchConfiguration('params_file',   default=os.path.join(pkg_nav, 'config', 'nav2_params.yaml'))
    rviz_config   = LaunchConfiguration('rviz_config',   default=os.path.join(pkg_nav, 'rviz', 'navigation.rviz'))
    use_rviz      = LaunchConfiguration('use_rviz',      default='true')
    autostart     = LaunchConfiguration('autostart',     default='true')

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time',  default_value='true'),
        DeclareLaunchArgument('map',           default_value=os.path.join(pkg_nav, 'maps', 'constrained_indoor.yaml'),
                              description='Full path to map yaml file'),
        DeclareLaunchArgument('params_file',   default_value=os.path.join(pkg_nav, 'config', 'nav2_params.yaml')),
        DeclareLaunchArgument('rviz_config',   default_value=os.path.join(pkg_nav, 'rviz', 'navigation.rviz')),
        DeclareLaunchArgument('use_rviz',      default_value='true'),
        DeclareLaunchArgument('autostart',     default_value='true'),

        # Nav2 full stack
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_nav2, 'launch', 'bringup_launch.py')
            ),
            launch_arguments={
                'map':           map_yaml_file,
                'use_sim_time':  use_sim_time,
                'params_file':   params_file,
                'autostart':     autostart,
            }.items(),
        ),

        # RViz2
        Node(
            condition=IfCondition(use_rviz),
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config],
            parameters=[{'use_sim_time': use_sim_time}],
            output='screen',
        ),
    ])
