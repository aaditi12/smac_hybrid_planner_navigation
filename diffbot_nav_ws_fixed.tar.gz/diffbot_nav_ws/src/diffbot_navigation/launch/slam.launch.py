import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_nav  = get_package_share_directory('diffbot_navigation')
    pkg_sim  = get_package_share_directory('diffbot_sim')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    slam_params_file = os.path.join(pkg_nav, 'config', 'slam_toolbox_params.yaml')
    rviz_config      = os.path.join(pkg_nav, 'rviz', 'navigation.rviz')

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),

        # Launch Gazebo world
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_sim, 'launch', 'gazebo.launch.py')
            ),
        ),

        # SLAM Toolbox in async online mode
        Node(
            package='slam_toolbox',
            executable='async_slam_toolbox_node',
            name='slam_toolbox',
            output='screen',
            parameters=[slam_params_file, {'use_sim_time': use_sim_time}],
        ),

        # Teleop keyboard for exploration
        Node(
            package='teleop_twist_keyboard',
            executable='teleop_twist_keyboard',
            name='teleop_twist_keyboard',
            output='screen',
            prefix='xterm -e',
        ),

        # RViz for monitoring
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config],
            parameters=[{'use_sim_time': use_sim_time}],
            output='screen',
        ),
    ])
