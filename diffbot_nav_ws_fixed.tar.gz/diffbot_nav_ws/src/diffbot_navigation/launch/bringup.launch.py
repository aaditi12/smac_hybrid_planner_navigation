import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    pkg_nav  = get_package_share_directory('diffbot_navigation')
    pkg_sim  = get_package_share_directory('diffbot_sim')

    use_sim_time  = LaunchConfiguration('use_sim_time',  default='true')
    map_yaml_file = LaunchConfiguration('map',           default=os.path.join(pkg_nav, 'maps', 'constrained_indoor.yaml'))
    params_file   = LaunchConfiguration('params_file',   default=os.path.join(pkg_nav, 'config', 'nav2_params.yaml'))

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time',  default_value='true'),
        DeclareLaunchArgument('map',           default_value=os.path.join(pkg_nav, 'maps', 'constrained_indoor.yaml')),
        DeclareLaunchArgument('params_file',   default_value=os.path.join(pkg_nav, 'config', 'nav2_params.yaml')),

        # Start Gazebo first
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_sim, 'launch', 'gazebo.launch.py')
            ),
        ),

        # Delay Nav2 to allow Gazebo, robot_state_publisher, and the robot
        # spawn to fully settle first (gazebo.launch.py now delays the spawn
        # itself by 6s to avoid a startup race, so Nav2 needs to wait longer
        # than that on top of its own action-server startup time).
        TimerAction(
            period=10.0,
            actions=[
                IncludeLaunchDescription(
                    PythonLaunchDescriptionSource(
                        os.path.join(pkg_nav, 'launch', 'navigation.launch.py')
                    ),
                    launch_arguments={
                        'map':          map_yaml_file,
                        'use_sim_time': use_sim_time,
                        'params_file':  params_file,
                    }.items(),
                ),
            ],
        ),
    ])
