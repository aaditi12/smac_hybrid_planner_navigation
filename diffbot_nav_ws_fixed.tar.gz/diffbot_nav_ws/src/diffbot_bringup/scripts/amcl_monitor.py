#!/usr/bin/env python3
"""
AMCL Localization Monitor
==========================
Subscribes to /amcl_pose and /particle_cloud, prints localization
quality metrics to terminal including:
  - Position estimate (x, y, yaw)
  - Covariance (x, y, theta)
  - Particle spread (effective sample size proxy)
  - Localization health: GOOD / UNCERTAIN / LOST

Usage:
  ros2 run diffbot_bringup amcl_monitor.py
"""

import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav2_msgs.msg import ParticleCloud


def quat_to_yaw(q) -> float:
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)


class AmclMonitor(Node):
    def __init__(self):
        super().__init__('amcl_monitor')

        self._pose_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/amcl_pose', self._pose_cb, 10)
        self._particles_sub = self.create_subscription(
            ParticleCloud, '/particle_cloud', self._particles_cb, 10)

        self._n_particles  = 0
        self._particle_std = 0.0

        self.get_logger().info('AMCL Monitor active. Listening to /amcl_pose ...')
        self.get_logger().info('─' * 60)

    def _particles_cb(self, msg):
        """Compute spread of particle cloud as localization quality proxy."""
        if not msg.particles:
            return
        self._n_particles = len(msg.particles)
        xs = [p.pose.position.x for p in msg.particles]
        ys = [p.pose.position.y for p in msg.particles]
        mx = sum(xs) / len(xs)
        my = sum(ys) / len(ys)
        variance = sum((x-mx)**2 + (y-my)**2 for x, y in zip(xs, ys)) / len(xs)
        self._particle_std = math.sqrt(variance)

    def _pose_cb(self, msg: PoseWithCovarianceStamped):
        pos = msg.pose.pose.position
        ori = msg.pose.pose.orientation
        cov = msg.pose.covariance

        yaw      = quat_to_yaw(ori)
        cov_x    = cov[0]
        cov_y    = cov[7]
        cov_yaw  = cov[35]
        max_cov  = max(cov_x, cov_y)

        # Health assessment
        if max_cov < 0.05 and self._particle_std < 0.15:
            health = '✅ GOOD'
        elif max_cov < 0.2 and self._particle_std < 0.4:
            health = '⚠️  UNCERTAIN'
        else:
            health = '🔴 LOST'

        print(
            f"\r[AMCL] pos=({pos.x:+6.3f}, {pos.y:+6.3f})m  "
            f"yaw={math.degrees(yaw):+7.2f}°  "
            f"cov=({cov_x:.4f},{cov_y:.4f},{cov_yaw:.4f})  "
            f"particles={self._n_particles}  spread={self._particle_std:.3f}  "
            f"{health}    ",
            end='', flush=True,
        )


def main():
    rclpy.init()
    node = AmclMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print('\nAMCL monitor stopped.')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
