#!/usr/bin/env python3
"""
Waypoint Mission for Diffbot - Constrained Indoor Navigation
============================================================
Sends sequential navigation goals through the indoor environment:
  Start -> Corridor mid -> Room A -> Back to corridor -> Room B -> Tight zone -> Home

Uses Nav2 NavigateToPose action with AMCL localization and Smac Hybrid-A* planner.

Usage:
  ros2 run diffbot_bringup waypoint_mission.py
  ros2 run diffbot_bringup waypoint_mission.py --ros-args -p loop:=true
"""

import math
import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.duration import Duration
from nav2_msgs.action import NavigateToPose, NavigateThroughPoses
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped
from nav_msgs.msg import Path
from std_msgs.msg import ColorRGBA
from visualization_msgs.msg import Marker, MarkerArray
from action_msgs.msg import GoalStatus
from rcl_interfaces.msg import ParameterDescriptor
import tf2_ros


def make_pose(x: float, y: float, yaw: float, frame='map') -> PoseStamped:
    """Create a PoseStamped from x, y, yaw (radians)."""
    pose = PoseStamped()
    pose.header.frame_id = frame
    pose.pose.position.x = float(x)
    pose.pose.position.y = float(y)
    pose.pose.position.z = 0.0
    # Convert yaw to quaternion
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    pose.pose.orientation.x = 0.0
    pose.pose.orientation.y = 0.0
    pose.pose.orientation.z = sy
    pose.pose.orientation.w = cy
    return pose


# ─── MISSION DEFINITION ─────────────────────────────────────────────────────
#
# Waypoints carefully chosen to:
#  1. Navigate through 1.2m wide main corridor
#  2. Enter 0.7m doorways into rooms
#  3. Maneuver past obstacles in rooms
#  4. Transit through tight pillar zone (0.6m effective gap per side)
#  5. Return to start
#
WAYPOINTS = [
    {
        'name':  'CorridorEntry',
        'x':      1.0,
        'y':      0.0,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'Enter main corridor heading east',
    },
    {
        'name':  'RoomA_Approach',
        'x':      1.8,
        'y':      0.0,
        'yaw':    1.5708,  # face north toward Room A door
        'planner': 'SmacHybrid',
        'note':  'Approach Room A doorway (0.7m gap at x=1.5-2.2)',
    },
    {
        'name':  'RoomA_Inside',
        'x':      1.5,
        'y':      2.0,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'Navigate inside Room A, avoid table at (2.0, 2.5)',
    },
    {
        'name':  'RoomA_Corner',
        'x':      0.5,
        'y':      3.5,
        'yaw':   -1.5708,  # face south
        'planner': 'SmacHybrid',
        'note':  'Far corner of Room A, turn around',
    },
    {
        'name':  'RoomA_Exit',
        'x':      1.8,
        'y':      0.3,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'Exit Room A back to corridor',
    },
    {
        'name':  'CorridorMid',
        'x':      4.0,
        'y':      0.0,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'Mid corridor, between rooms',
    },
    {
        'name':  'RoomB_Approach',
        'x':      5.8,
        'y':      0.0,
        'yaw':    1.5708,
        'planner': 'SmacHybrid',
        'note':  'Approach Room B doorway (x=5.5-6.2)',
    },
    {
        'name':  'RoomB_Inside',
        'x':      7.0,
        'y':      2.5,
        'yaw':    3.14159,  # face west
        'planner': 'SmacHybrid',
        'note':  'Inside Room B, avoid shelves at y=3.5',
    },
    {
        'name':  'RoomB_Exit',
        'x':      5.8,
        'y':      0.3,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'Exit Room B',
    },
    {
        'name':  'PrePillarZone',
        'x':      9.5,
        'y':      0.0,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'Approach tight pillar zone - reduce speed',
    },
    {
        'name':  'BetweenPillars',
        'x':     10.5,
        'y':      0.0,
        'yaw':    0.0,
        'planner': 'SmacHybrid',
        'note':  'TIGHT: between pillars, gap ~0.36m each side of robot',
    },
    {
        'name':  'CorridorEnd',
        'x':     11.5,
        'y':      0.0,
        'yaw':    3.14159,  # face back west
        'planner': 'SmacHybrid',
        'note':  'End of corridor, turn 180',
    },
    {
        'name':  'ReturnMid',
        'x':      6.0,
        'y':      0.0,
        'yaw':    3.14159,
        'planner': 'SmacHybrid',
        'note':  'Return journey, heading west',
    },
    {
        'name':  'Home',
        'x':     -0.5,
        'y':      0.0,
        'yaw':    0.0,
        'planner': 'GridBased',  # Simple A* for final approach
        'note':  'Return to start position',
    },
]


class WaypointMission(Node):
    """
    Sends Nav2 NavigateToPose goals sequentially.
    Monitors AMCL covariance and warns if localization uncertainty is high.
    Publishes waypoint markers to RViz.
    """

    def __init__(self):
        super().__init__('waypoint_mission')

        # Parameters
        self.declare_parameter('loop', False,
            ParameterDescriptor(description='Loop the mission indefinitely'))
        self.declare_parameter('planner_override', '',
            ParameterDescriptor(description='Force a specific planner (SmacHybrid|GridBased)'))
        self.declare_parameter('pose_uncertainty_warn', 0.3,
            ParameterDescriptor(description='AMCL covariance threshold for warning'))

        self._loop             = self.get_parameter('loop').value
        self._planner_override = self.get_parameter('planner_override').value
        self._cov_warn_thresh  = self.get_parameter('pose_uncertainty_warn').value

        # Nav2 action client
        self._nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # Publishers
        self._marker_pub = self.create_publisher(MarkerArray, '/waypoint_markers', 10)
        self._init_pose_pub = self.create_publisher(
            PoseWithCovarianceStamped, '/initialpose', 10)

        # AMCL subscription
        self._amcl_sub = self.create_subscription(
            PoseWithCovarianceStamped,
            '/amcl_pose',
            self._amcl_callback,
            10,
        )
        self._latest_covariance = None
        self._mission_complete = False

        # TF buffer used to confirm AMCL has actually published map->odom
        # before we start sending goals. Without this check, bt_navigator
        # aborts every goal instantly ("Empty Tree") if that transform
        # isn't ready yet, which looks like a planner failure but is really
        # a localization-not-ready race.
        self._tf_buffer = tf2_ros.Buffer()
        self._tf_listener = tf2_ros.TransformListener(self._tf_buffer, self)

        self.get_logger().info('=== Diffbot Waypoint Mission Node Started ===')
        self.get_logger().info(f'  Waypoints: {len(WAYPOINTS)}')
        self.get_logger().info(f'  Loop mode: {self._loop}')
        self.get_logger().info(f'  Planner override: "{self._planner_override or "per-waypoint"}"')

    def _amcl_callback(self, msg: PoseWithCovarianceStamped):
        cov = msg.pose.covariance
        self._latest_covariance = (cov[0], cov[7], cov[35])  # xx, yy, th_th
        if max(cov[0], cov[7]) > self._cov_warn_thresh:
            self.get_logger().warn(
                f'[AMCL] High pose uncertainty! cov_x={cov[0]:.4f} cov_y={cov[7]:.4f}')

    def publish_markers(self):
        """Publish sphere markers at each waypoint in RViz."""
        markers = MarkerArray()
        for i, wp in enumerate(WAYPOINTS):
            m = Marker()
            m.header.frame_id = 'map'
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = 'waypoints'
            m.id = i
            m.type = Marker.SPHERE
            m.action = Marker.ADD
            m.pose.position.x = float(wp['x'])
            m.pose.position.y = float(wp['y'])
            m.pose.position.z = 0.15
            m.scale.x = 0.18
            m.scale.y = 0.18
            m.scale.z = 0.18
            m.color.a = 0.9
            # Color code: green=unvisited, yellow=active, blue=done
            m.color.r = 0.2
            m.color.g = 0.8
            m.color.b = 0.2

            # Text marker
            t = Marker()
            t.header = m.header
            t.ns = 'waypoint_labels'
            t.id = i + 1000
            t.type = Marker.TEXT_VIEW_FACING
            t.action = Marker.ADD
            t.pose.position.x = float(wp['x'])
            t.pose.position.y = float(wp['y'])
            t.pose.position.z = 0.4
            t.scale.z = 0.15
            t.color.a = 1.0
            t.color.r = 1.0
            t.color.g = 1.0
            t.color.b = 1.0
            t.text = f"{i+1}:{wp['name']}"

            markers.markers.append(m)
            markers.markers.append(t)
        self._marker_pub.publish(markers)

    def set_initial_pose(self):
        """
        Publish initial pose to AMCL, retrying until the map->odom transform
        actually appears. A single publish can be dropped or ignored if AMCL
        hasn't fully activated yet, which otherwise leads to every later
        NavigateToPose goal aborting instantly with "Empty Tree" because
        bt_navigator can't resolve the 'map' frame.
        """
        self.get_logger().info('Publishing initial pose to AMCL...')
        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = 'map'
        msg.pose.pose.position.x = -0.5
        msg.pose.pose.position.y = 0.0
        msg.pose.pose.orientation.w = 1.0
        # Initial covariance
        msg.pose.covariance[0]  = 0.25
        msg.pose.covariance[7]  = 0.25
        msg.pose.covariance[35] = 0.0685

        deadline = time.time() + 30.0
        while time.time() < deadline:
            msg.header.stamp = self.get_clock().now().to_msg()
            self._init_pose_pub.publish(msg)
            rclpy.spin_once(self, timeout_sec=0.5)
            if self._tf_buffer.can_transform(
                    'map', 'odom', rclpy.time.Time()):
                self.get_logger().info('map -> odom transform is available.')
                return True
            time.sleep(0.5)

        self.get_logger().error(
            'Timed out waiting for map->odom transform after publishing '
            'initial pose. AMCL may not be active yet.')
        return False

    def wait_for_nav2(self, timeout=60.0):
        """Wait for Nav2 action server."""
        self.get_logger().info('Waiting for Nav2 NavigateToPose action server...')
        start = time.time()
        while not self._nav_client.wait_for_server(timeout_sec=1.0):
            if time.time() - start > timeout:
                self.get_logger().error('Nav2 not available after timeout!')
                return False
            self.get_logger().info('  ... still waiting for Nav2 ...')
        self.get_logger().info('Nav2 is ready!')
        return True

    def navigate_to(self, wp: dict) -> bool:
        """
        Send a single NavigateToPose goal and wait for result.
        Returns True on success, False on failure/cancel.
        """
        pose = make_pose(wp['x'], wp['y'], wp['yaw'])
        pose.header.stamp = self.get_clock().now().to_msg()

        planner = self._planner_override or wp.get('planner', 'SmacHybrid')

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose
        goal_msg.behavior_tree = ''  # use default BT

        self.get_logger().info(
            f"  → [{wp['name']}] ({wp['x']:.2f}, {wp['y']:.2f}, yaw={math.degrees(wp['yaw']):.0f}°)"
            f"  planner={planner}  |  {wp.get('note','')}"
        )

        # Send goal
        send_future = self._nav_client.send_goal_async(
            goal_msg,
            feedback_callback=self._feedback_callback,
        )
        rclpy.spin_until_future_complete(self, send_future)
        goal_handle = send_future.result()

        if not goal_handle.accepted:
            self.get_logger().error(f"  Goal REJECTED for {wp['name']}")
            return False

        # Wait for result
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        status = result_future.result().status

        if status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info(f"  ✓ Reached {wp['name']}")
            return True
        else:
            self.get_logger().warn(f"  ✗ Failed to reach {wp['name']} (status={status})")
            return False

    def _feedback_callback(self, feedback_msg):
        """Log distance remaining periodically."""
        feedback = feedback_msg.feedback
        dist = feedback.distance_remaining
        if dist > 0.5:
            self.get_logger().info(f'    distance remaining: {dist:.2f}m', throttle_duration_sec=3.0)

    def run_mission(self):
        """Execute the full waypoint mission."""
        if not self.wait_for_nav2():
            return

        if not self.set_initial_pose():
            self.get_logger().error(
                'Aborting mission: localization never became ready. '
                'Check that AMCL is active (ros2 lifecycle get /amcl) and '
                'that use_sim_time is consistent across nodes.')
            return

        run = 0
        while True:
            run += 1
            self.get_logger().info(f'\n{"="*60}')
            self.get_logger().info(f'  MISSION RUN #{run}  ({len(WAYPOINTS)} waypoints)')
            self.get_logger().info(f'{"="*60}')

            self.publish_markers()
            successes = 0
            failures  = 0

            for i, wp in enumerate(WAYPOINTS):
                self.get_logger().info(f'\n[{i+1}/{len(WAYPOINTS)}] Navigating to: {wp["name"]}')
                self.publish_markers()

                ok = self.navigate_to(wp)
                if ok:
                    successes += 1
                else:
                    failures += 1
                    self.get_logger().warn('  Attempting recovery: waiting 2s then continuing...')
                    time.sleep(2.0)

            self.get_logger().info(f'\n{"="*60}')
            self.get_logger().info(f'  RUN #{run} COMPLETE: {successes}/{len(WAYPOINTS)} succeeded, {failures} failed')
            self.get_logger().info(f'{"="*60}\n')

            if not self._loop:
                break

        self.get_logger().info('Mission finished. Shutting down.')
        self._mission_complete = True


def main(args=None):
    rclpy.init(args=args)
    node = WaypointMission()
    try:
        node.run_mission()
    except KeyboardInterrupt:
        node.get_logger().info('Mission interrupted by user.')
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
