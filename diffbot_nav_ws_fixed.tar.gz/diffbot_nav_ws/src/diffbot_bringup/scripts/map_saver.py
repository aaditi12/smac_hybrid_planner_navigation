#!/usr/bin/env python3
"""
Map Saver Utility
=================
Saves the current SLAM map to disk.

Usage:
  ros2 run diffbot_bringup map_saver.py
  ros2 run diffbot_bringup map_saver.py --ros-args -p output_path:=/home/user/my_map
"""

import rclpy
from rclpy.node import Node
from nav2_msgs.srv import SaveMap
import os
import time


class MapSaverNode(Node):
    def __init__(self):
        super().__init__('map_saver_node')
        self.declare_parameter('output_path', '/tmp/diffbot_map')
        self._output_path = self.get_parameter('output_path').value

        self._client = self.create_client(SaveMap, '/map_saver/save_map')
        self.get_logger().info(f'Map will be saved to: {self._output_path}')

    def save(self):
        if not self._client.wait_for_service(timeout_sec=10.0):
            self.get_logger().error('map_saver service not available')
            return False

        req = SaveMap.Request()
        req.map_topic = 'map'
        req.map_url   = self._output_path
        req.image_format = 'pgm'
        req.map_mode     = 'trinary'
        req.free_thresh   = 0.25
        req.occupied_thresh = 0.65

        future = self._client.call_async(req)
        rclpy.spin_until_future_complete(self, future, timeout_sec=15.0)

        if future.result() and future.result().result:
            self.get_logger().info(f'Map saved successfully to {self._output_path}.pgm/.yaml')
            return True
        else:
            self.get_logger().error('Map save failed!')
            return False


def main():
    rclpy.init()
    node = MapSaverNode()
    node.save()
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
