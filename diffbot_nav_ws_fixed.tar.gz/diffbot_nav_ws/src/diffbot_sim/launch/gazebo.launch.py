import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, ExecuteProcess,
                             IncludeLaunchDescription, SetEnvironmentVariable,
                             TimerAction)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_sim  = get_package_share_directory('diffbot_sim')
    pkg_desc = get_package_share_directory('diffbot_description')
    pkg_gz   = get_package_share_directory('gazebo_ros')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    x_pose       = LaunchConfiguration('x_pose',       default='-0.5')
    y_pose       = LaunchConfiguration('y_pose',       default='0.0')

    world_file   = os.path.join(pkg_sim, 'worlds', 'constrained_indoor.world')
    urdf_file    = os.path.join(pkg_desc, 'urdf', 'diffbot.urdf.xacro')

    robot_description = Command(['xacro ', urdf_file])

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),
        DeclareLaunchArgument('x_pose',       default_value='-0.5'),
        DeclareLaunchArgument('y_pose',       default_value='0.0'),

        SetEnvironmentVariable('LIBGL_ALWAYS_SOFTWARE', '1'),

        # Launch Gazebo
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(pkg_gz, 'launch', 'gazebo.launch.py')
            ),
            launch_arguments={'world': world_file, 'verbose': 'false'}.items(),
        ),

        # Robot State Publisher - delayed slightly so it doesn't race Gazebo's
        # own startup (important on slow/software-rendered VMs)
        TimerAction(
            period=2.0,
            actions=[
                Node(
                    package='robot_state_publisher',
                    executable='robot_state_publisher',
                    name='robot_state_publisher',
                    output='screen',
                    parameters=[{
                        'use_sim_time': use_sim_time,
                        'robot_description': robot_description,
                    }],
                ),
            ],
        ),

        # Spawn robot in Gazebo - delayed further so Gazebo has finished
        # loading the world/physics AND robot_state_publisher has already
        # published a full robot_description at least once. Without this,
        # spawn_entity.py can grab a stale/partial message or spawn before
        # the world's collision geometry is ready, and physics will resolve
        # the resulting interpenetration by shoving the robot into a wall.
        TimerAction(
            period=6.0,
            actions=[
                Node(
                    package='gazebo_ros',
                    executable='spawn_entity.py',
                    name='spawn_diffbot',
                    output='screen',
                    arguments=[
                        '-topic', 'robot_description',
                        '-entity', 'diffbot',
                        '-x', x_pose,
                        '-y', y_pose,
                        '-z', '0.05',
                        '-Y', '0.0',
                    ],
                ),
            ],
        ),
    ])
